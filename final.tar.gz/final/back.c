#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "back.h"

typedef struct datos{
	char * nombre;
	int habitantes;
	int analfabetos;
	long int sumaEdades;
} datos;

/* Segunda esctructura principal del TAD, se utiliza para guardar datos importantes que se necesitaron para el procesamiento de datos del censo*/

typedef struct tLista{
	datos datosProv;
	struct node * dptos;
}tLista;

/*Header de las listas, contiene la informacion de cada provincia y una lista de los departamentos de la provincia*/

typedef struct censoCDT{
	tLista * listaProv;
	datos * viviendas;
	int cntprov;
	int cntviv;
}censoCDT;

/*Estructura principal del TAD, contiene una vector de listas con header llamada listaProv, un vector de estructuras datos llamada viviendas y las dimensiones respectivas
de cada uno*/

typedef struct node{
	datos datosDpto;
	struct node * next;
}node;

/*Lista, contiene los datos y un nodo a la sublista*/

/*Todas las funciones que terminan con R(por ejemplo addR) son funciones auxiliares para usar recursivamente sobre las listas*/
static struct node * addR(struct node *, int, char *, int *);
static void printProvinciaR(struct node *);
static double indiceTotal(int primer, int segundo);
/*Devuelve 0 si primer es 0, si no devuelve primer/segundo en double.*/
static void freeDptos(struct node * nodo);
static void freeProvincias(struct tLista *, int );
static void freeViviendas(struct datos *, int);

censoADT newCenso(int cntviv, char ** viviendas, int cntprov, char ** provincias){
	int error=0;
	char * aux2;
	censoADT aux = calloc(1, sizeof(censoCDT));
	if(aux!=NULL){
		aux->cntprov=cntprov;
		aux->cntviv=cntviv;
		aux->listaProv=calloc(cntprov, sizeof(tLista));
		if(aux->listaProv==NULL)
			free(aux);
		else{
			for(int i=0; i<cntprov &&!error; i++){
				aux2=malloc(strlen(provincias[i])+1);
				if(aux2==NULL){
					freeProvincias(aux->listaProv,i);
					error=1;
					free(aux);
					aux=NULL;
				}
				else{
					aux->listaProv[i].datosProv.nombre=aux2;
					strcpy(aux->listaProv[i].datosProv.nombre,provincias[i]);
					aux->listaProv[i].dptos=NULL;
				}	
			}
			if(!error){
				aux->viviendas=calloc(cntviv, sizeof(datos));
				if(aux->viviendas==NULL){
					freeProvincias(aux->listaProv,cntprov);
					free(aux);
					aux=NULL;
				}
				else{
					for(int i=0; i<cntviv && !error; i++){
						aux2=malloc(strlen(viviendas[i])+1);
						if(aux2==NULL){
							error=1;
							freeProvincias(aux->listaProv,cntprov);
							freeViviendas(aux->viviendas,i);
							free(aux);
							aux=NULL;
						}
						else{
							aux->viviendas[i].nombre=aux2;
							strcpy(aux->viviendas[i].nombre,viviendas[i]);
						}
					}
				}
			}
		}
	}
	return aux;
}

void printProvincias(censoADT censo){
	int i;
	for(i=0; i<censo->cntprov;i++){
		printf("%s\n", censo->listaProv[i].datosProv.nombre);
	}
}

void printViviendas(censoADT censo){
	int i;
	for(i=0; i<censo->cntviv;i++){
		printf("%s\n", censo->viviendas[i].nombre);
	}
}

int add(censoADT censo, int edad, int alfa, int vivienda, char * dpto, int provincia){
	int error=0;
	provincia--;
	vivienda--;
	censo->viviendas[vivienda].habitantes++;
	censo->listaProv[provincia].datosProv.habitantes++;
	censo->listaProv[provincia].datosProv.sumaEdades+=edad;
	if(alfa==1){
		censo->listaProv[provincia].datosProv.analfabetos++;
		censo->viviendas[vivienda].analfabetos++;
	}
	censo->listaProv[provincia].dptos=addR(censo->listaProv[provincia].dptos, alfa, dpto ,&error);
	return error;
}

/*El parametro adicional del puntero a entero es para poder verificar si hubo algun error*/

static node * addR(struct node * nodo, int alfa, char * dpto, int * error){
	int c;
	if(nodo==NULL || (c=strcmp(nodo->datosDpto.nombre,dpto))>0)
	    {
	        node * aux=calloc(1,sizeof(*aux));
	        if(aux==NULL){
	        	*error=1;
	        	return nodo;
	        }
	        aux->datosDpto.habitantes=1;
	        if(alfa==1)
				aux->datosDpto.analfabetos=1;
	        aux->datosDpto.nombre=malloc(strlen(dpto)+1);
	        if(aux->datosDpto.nombre==NULL){
	        	*error=1;
	        	free(aux);
	        	return nodo;
	        }
	        strcpy(aux->datosDpto.nombre,dpto);
	        aux->next=nodo;
	        return aux;
	    }
	else if(c==0){
		if(alfa==1)
			nodo->datosDpto.analfabetos++;
		nodo->datosDpto.habitantes++;
		return nodo;
	}
	nodo->next=addR(nodo->next,alfa,dpto,error);
	return nodo;
}


void printProvincia(censoADT censo, int provincia){
	provincia--;
	printf("Habitantes de la provincia y analfabetos:\n%d\n%d\n", censo->listaProv[provincia].datosProv.habitantes, censo->listaProv[provincia].datosProv.analfabetos);
	printProvinciaR(censo->listaProv[provincia].dptos);
}

static void printProvinciaR(struct node * nodo){
	if (nodo==NULL)
		return;
	printf("Habitantes del dpto: %s y analfabetos:\n%d\n%d\n", nodo->datosDpto.nombre, nodo->datosDpto.habitantes, nodo->datosDpto.analfabetos);
	printProvinciaR(nodo->next);
}


static double indiceTotal(int analfabetos, int personas)
{   if (analfabetos==0)
	return 0;
	return ((double)analfabetos)/personas;
}

void analfabetismoCsv(censoADT censo)
{
    FILE* fp;
    int i;
    fp=fopen("./Analfabetismo.csv","w");
    for(i=0;i<censo->cntviv;i++){
        fprintf(fp,"%d,%s,%d,%4.2f\n",i+1,censo->viviendas[i].nombre,censo->viviendas[i].habitantes,indiceTotal(censo->viviendas[i].analfabetos, censo->viviendas[i].habitantes));
    }
    fclose(fp);
}

void provinciaCsv(censoADT censo)
{
    FILE* fp;
    int i;
    fp=fopen("Provincia.csv","w");
    for(i=0;i<censo->cntprov;i++){
        fprintf(fp,"%s,%d,%4.2f,%4.2f\n",censo->listaProv[i].datosProv.nombre,censo->listaProv[i].datosProv.habitantes,indiceTotal(censo->listaProv[i].datosProv.sumaEdades, censo->listaProv[i].datosProv.habitantes)
        	,indiceTotal(censo->listaProv[i].datosProv.analfabetos, censo->listaProv[i].datosProv.habitantes));
    }
    fclose(fp);
}

void departamentoCsv(censoADT censo)
{
    FILE* fp;
    int i;
    fp=fopen("Departamentos.csv","w");
    for(i=0;i<censo->cntprov;i++)
    {
    	struct node * aux=censo->listaProv[i].dptos;
    	while(aux!=NULL)
				{
					fprintf(fp,"%s,%s,%d,%4.2f\n",censo->listaProv[i].datosProv.nombre,aux->datosDpto.nombre,aux->datosDpto.habitantes,
						indiceTotal(aux->datosDpto.analfabetos,aux->datosDpto.habitantes));
					aux=aux->next;
				}
    }
    fclose(fp);
}


static void freeDptos(node * nodo){
	if(nodo==NULL)
		return;
	freeDptos(nodo->next);
	free(nodo->datosDpto.nombre);
	free(nodo);
}

static void freeProvincias(tLista * provincias, int cntprov){
	for(int i=0; i<cntprov; i++){
		free(provincias[i].datosProv.nombre);
		freeDptos(provincias[i].dptos);
	}
	free(provincias);
}

static void freeViviendas(datos * viviendas, int cntviv){
	for(int i=0; i<cntviv;i++)
		free(viviendas[i].nombre);
	free(viviendas);
}

void freeCenso(censoADT censo){
	freeProvincias(censo->listaProv, censo->cntprov);
	freeViviendas(censo->viviendas,censo->cntviv);
	free(censo);
}