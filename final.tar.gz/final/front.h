#ifndef FRONTEND_H
#define FRONTEND_H

#include <stdio.h>
#include "back.h"

#define CNTDATOSNUM 4
#define CNTPROV 24
#define CNTVIV 9
#define MAXLINEA 80

enum {NUMERO,PALABRA};

int agregarGenteArchivo(censoADT censo);
/*Funcion que recive un censo y agrega gente al censo desde un archivo, lee hasta llegar a EOF. Devuelve 0 si no hubo ningun problema, 1 si hubo un error*/
censoADT newCensoArgentino(void);
/*Crea un censo con los parametros pedidos en el trabajo pratico*/

#endif