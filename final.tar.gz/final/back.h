#ifndef BACK_H321
#define BACK_H321

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct censoCDT * censoADT;


censoADT newCenso(int cntviv, char ** viviendas, int cntprov, char ** provincias);
/*Funcion que crea un nuevo TAD censo, al que se le pasan como parametros la cantidad de viviendas, un vector de strings el cual tiene los nombres de las viviendas(
cntviviendas seria el lenght de este string), y de igual manera la cantidad de provincias y un vector con los nombres de las provincias. Aclaracion: El codigo de cada
vivienda/provincia va a ser la posicion del vector+1. Por lo tanto si el primer elemento de viviendas es "Ciudad autonoma de Buenos Aires", esta sera la provincia de codigo 1*/
int add(censoADT censo, int edad, int alfa, int vivienda, char * dpto, int provincia);
/*Funcion para agregar los datos de una persona al censo. En orden los parametros son: el objeto censo, la edad de la persona, si es analfabeta o no (1 es analfabeto, 2 no),
el codigo de vivienda, el nombre del departamento donde vive y el codigo de provincia. Devuelve 1 si pudo agregar a la persona o 0 si no*/
void analfabetismoCsv(censoADT censo);
/*Funcion que crea un archivo "Analfabetismo.csv" en la carpeta actual del programa. Este archivo es del estilo csv(Comma separated value), con los siguientes campos:
codigo de tipo de vivienda,tipo de vivienda(string), cantidad de habitantes, indice de analfabetismo(numero de analfabetas sobre numero de habitantes,
con 2 numeros despues de la coma y redondeado). Un ejemplo de una linea seria:
1,Casa,23,0.80
*/
void provinciaCsv(censoADT censo);
/*Funcion que crea un archivo "Provincia.csv" en la carpeta actual del programa. Este archivo es del estilo csv(Comma separated value), con los siguientes campos:
Nombre de la provincia(string), cantidad de habitantes, promedio de edad(suma de todas las edades sobre habitantes, con dos numeros despues de la coma y redondeado)
, indice de analfabetismo(numero de analfabetas sobre numero de habitantes,con 2 numeros despues de la coma y redondeado). Un ejemplo de una linea seria:
Buenos Aires,102,44.43,0.32
*/
void departamentoCsv(censoADT censo);
/*Funcion que crea un archivo "Departamento.csv" en la carpeta actual del programa. Este archivo es del estilo csv(Comma separated value), con los siguientes campos:
Nombre de la provincia(string), Nombre del departamento, cantidad de habitantes, indice de analfabetismo(numero de analfabetas sobre numero de habitantes,
con 2 numeros despues de la coma y redondeado). Un ejemplo de una linea seria:
Buenos Aires,Haedo,594,1.00
*/
void freeCenso(censoADT censo);
/*Funcion que libera del Heap todos los recursos utilizados por el TAD*/
void printProvincias(censoADT);
/*Funcion que imprime cada provincia con sus habitantes y analfabetos*/
void printViviendas(censoADT);
/*Funcion que imprime cada vivienda con sus habitantes y analfabetos*/
void printProvincia(censoADT censo, int provincia);
/*Funcion que imprime la provincia indicada por el int provincia, con cada departamento dentro de ella, con su nombre, habitantes y 
cantidad de analfabetos*/

#endif