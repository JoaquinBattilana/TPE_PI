
#include "front.h"

int main(void){
	censoADT censo;
	censo = newCensoArgentino();
	if(censo!=NULL){
		if(agregarGenteArchivo(censo)==0){
			analfabetismoCsv(censo);
			provinciaCsv(censo);
			departamentoCsv(censo);
		}
		freeCenso(censo);
	}
	return 0;
}
